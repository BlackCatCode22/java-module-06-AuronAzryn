package alex.zoo.com;

public class Bear extends Animal {
    private static int numOfBear = 0;

    public Bear(String sex, String weight, int age, String name, String animalID, String animalBirthDate, String animalColor, String animalLocation, String animalState) {
        super(sex, "bear", weight, age, name, animalID, animalBirthDate, animalColor, animalLocation, animalState);
        ++numOfBear;
    }

    @Override
    public String toString() {
        return "Bear Habitat: " + getAnimalID() + "; "
                + getAnimalName() + "; "
                + "birth date: " + (getAnimalBirthDate() != null ? getAnimalBirthDate() : "Unknown") + "; "
                + getAnimalColor() + "; "
                + getSex() + "; "
                + getWeight() + "; "
                + "from " + getAnimalLocation() + "; "
                + "arrived " + getAnimalArrivalDate();
    }

    public static int getNumOfBear() {
        return numOfBear;
    }
}
