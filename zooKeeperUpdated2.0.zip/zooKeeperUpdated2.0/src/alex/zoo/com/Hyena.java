package alex.zoo.com;

public class Hyena extends Animal {
    private static int numOfHyena = 0;

    public Hyena(String sex, String weight, int age, String name, String animalID, String animalBirthDate, String animalColor, String animalLocation, String animalState) {
        super(sex, "hyena", weight, age, name, animalID, animalBirthDate, animalColor, animalLocation, animalState);
        ++numOfHyena;
    }

    @Override
    public String toString() {
        return "Hyena Habitat: " + getAnimalID() + "; "
                + getAnimalName() + "; "
                + "birth date: " + (getAnimalBirthDate() != null ? getAnimalBirthDate() : "Unknown") + "; "
                + getAnimalColor() + "; "
                + getSex() + "; "
                + getWeight() + "; "
                + "from " + getAnimalLocation() + "; "
                + "arrived " + getAnimalArrivalDate();
    }

    public static int getNumOfHyena() {
        return numOfHyena;
    }
}
