package alex.zoo.com;

import java.util.ArrayList;

public class AnimalNameListsWrapper {
    private ArrayList<String> hyenaNames;
    private ArrayList<String> lionNames;
    private ArrayList<String> tigerNames;
    private ArrayList<String> bearNames;

    public AnimalNameListsWrapper(ArrayList<String> hyenaNameList,
                                  ArrayList<String> lionNameList,
                                  ArrayList<String> tigerNameList,
                                  ArrayList<String> bearNameList) {
        this.hyenaNames = hyenaNameList;
        this.lionNames = lionNameList;
        this.tigerNames = tigerNameList;
        this.bearNames = bearNameList;
    }

    public ArrayList<String> getHyenaNames() { return hyenaNames; }
    public ArrayList<String> getLionNames() { return lionNames; }
    public ArrayList<String> getTigerNames() { return tigerNames; }
    public ArrayList<String> getBearNames() { return bearNames; }
}
