package alex.zoo.com;

/**
 * Represents a generic Animal record in the zoo.
 * This class stores attributes common to all animals and
 * supports file reporting for the Zookeeper’s Challenge project.
 *
 * @author
 * @version 1.1
 * @since 2025-11-06
 */
public class Animal {

    // --- Static counter for all animals created ---
    private static int numOfAnimals;

    // --- Animal attributes ---
    private String species;
    private String animalName;
    private String animalID;
    private String sex;
    private String animalColor;
    private String weight;
    private int age;
    private String animalBirthDate;
    private String animalLocation;
    private String animalState;
    private String animalArrivalDate;

    /**
     * Primary constructor used for building Animal records from arrivingAnimals.txt
     *
     * @param species         The species (e.g., hyena, lion)
     * @param animalName      The animal's assigned name
     * @param animalID        The unique animal ID
     * @param sex             The sex (male/female)
     * @param animalColor     The animal's color
     * @param weight          The animal's weight in pounds
     * @param animalBirthDate The ISO 8601 formatted birth date
     * @param animalLocation  The origin location (e.g., Friguia Park)
     * @param animalState     The origin state/country
     * @param animalArrivalDate The date the animal arrived at the zoo
     */
    public Animal(String species, String animalName, String animalID, String sex,
                  String animalColor, String weight, String animalBirthDate,
                  String animalLocation, String animalState, String animalArrivalDate) {
        ++numOfAnimals;
        this.species = species;
        this.animalName = animalName;
        this.animalID = animalID;
        this.sex = sex;
        this.animalColor = animalColor;
        this.weight = weight;
        this.animalBirthDate = animalBirthDate;
        this.animalLocation = animalLocation;
        this.animalState = animalState;
        this.animalArrivalDate = animalArrivalDate;
    }

    // --- Optional legacy constructors kept for backward compatibility ---
    public Animal(String sex, String species, String weight, int age, String name,
                  String animalID, String animalBirthDate, String animalColor,
                  String animalLocation, String animalState) {
        ++numOfAnimals;
        this.sex = sex;
        this.species = species;
        this.weight = weight;
        this.age = age;
        this.animalName = name;
        this.animalID = animalID;
        this.animalBirthDate = animalBirthDate;
        this.animalColor = animalColor;
        this.animalLocation = animalLocation;
        this.animalState = animalState;
    }

    // --- Getters and Setters ---
    public static int getNumOfAnimals() { return numOfAnimals; }

    public String getSpecies() { return species; }
    public void setSpecies(String species) { this.species = species; }

    public String getAnimalName() { return animalName; }
    public void setAnimalName(String animalName) { this.animalName = animalName; }

    public String getAnimalID() { return animalID; }
    public void setAnimalID(String animalID) { this.animalID = animalID; }

    public String getSex() { return sex; }
    public void setSex(String sex) { this.sex = sex; }

    public String getAnimalColor() { return animalColor; }
    public void setAnimalColor(String animalColor) { this.animalColor = animalColor; }

    public String getWeight() { return weight; }
    public void setWeight(String weight) { this.weight = weight; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getAnimalBirthDate() { return animalBirthDate; }
    public void setAnimalBirthDate(String animalBirthDate) { this.animalBirthDate = animalBirthDate; }

    public String getAnimalLocation() { return animalLocation; }
    public void setAnimalLocation(String animalLocation) { this.animalLocation = animalLocation; }

    public String getAnimalState() { return animalState; }
    public void setAnimalState(String animalState) { this.animalState = animalState; }

    public String getAnimalArrivalDate() { return animalArrivalDate; }
    public void setAnimalArrivalDate(String animalArrivalDate) { this.animalArrivalDate = animalArrivalDate; }

    /**
     * Returns a formatted summary for zooPopulation.txt output
     *
     * @return Readable animal record line for the report
     */
    @Override
    public String toString() {
        return String.format("%s; %s; birth date: %s; %s; %s; %s; from %s, %s; arrived %s",
                animalID, animalName, animalBirthDate, animalColor, sex, weight,
                animalLocation, animalState, animalArrivalDate);
    }
}
