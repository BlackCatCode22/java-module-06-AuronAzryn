// aD 11/06/2025
package alex.zoo.com;

import java.io.*;
import java.time.LocalDate;
import java.util.*;

/**
 * Zookeeper's Challenge
 * ---------------------
 * Reads data from arrivingAnimals.txt and animalNames.txt,
 * assigns unique IDs and birthdays, organizes animals by species habitat,
 * and writes a detailed zooPopulation.txt report.
 *
 * Example Input:
 * 4 year old female hyena, born in spring, tan color, 70 pounds, from Friguia Park, Tunisia
 *
 * Example Output (zooPopulation.txt):
 * Hyena Habitat:
 * Hy01; Kamari; birth date: 2021-04-15; tan color; female; 70 pounds; from Friguia Park, Tunisia; arrived 2025-11-06
 */
public class App {

    public static void main(String[] args) {
        // --- Input / Output file paths ---
        String animalNamesPath = "animalNames.txt";
        String arrivingAnimalsPath = "arrivingAnimals.txt";
        String zooPopulationPath = "zooPopulation.txt";

        // --- Load name lists for each species ---
        AnimalNameListsWrapper animalLists = Utilities.createAnimalNameLists(animalNamesPath);

        ArrayList<String> hyenaNames = animalLists.getHyenaNames();
        ArrayList<String> lionNames = animalLists.getLionNames();
        ArrayList<String> bearNames = animalLists.getBearNames();
        ArrayList<String> tigerNames = animalLists.getTigerNames();

        // --- Store organized habitats ---
        LinkedHashMap<String, ArrayList<Animal>> habitats = new LinkedHashMap<>();
        habitats.put("Hyena Habitat", new ArrayList<>());
        habitats.put("Lion Habitat", new ArrayList<>());
        habitats.put("Tiger Habitat", new ArrayList<>());
        habitats.put("Bear Habitat", new ArrayList<>());

        // --- Process arriving animals ---
        try (BufferedReader reader = new BufferedReader(new FileReader(arrivingAnimalsPath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.isBlank()) continue;

                // Parse line: "4 year old female hyena, born in spring, tan color, 70 pounds, from Friguia Park, Tunisia"
                String[] parts = line.split(", ");
                if (parts.length < 5) continue;

                String[] first = parts[0].split(" ");
                int age = Integer.parseInt(first[0]);
                String sex = first[3];
                String species = first[4].toLowerCase();

                String birthSeason = parts[1].replace("born in ", "").trim();
                String color = parts[2].replace("color", "").trim();
                String weight = parts[3].replace("pounds", "").trim();
                String location = parts[4].replace("from ", "").trim();
                String state = (parts.length > 5) ? parts[5].trim() : "";

                // --- Generate animal data ---
                String birthDate = genBirthDay(age, birthSeason);
                String animalID = genUniqueID(species);
                String arrivalDate = Utilities.arrivalDate();

                // --- Assign name from lists ---
                String animalName = switch (species) {
                    case "hyena" -> getName(hyenaNames, habitats.get("Hyena Habitat").size(), "Hyena");
                    case "lion" -> getName(lionNames, habitats.get("Lion Habitat").size(), "Lion");
                    case "tiger" -> getName(tigerNames, habitats.get("Tiger Habitat").size(), "Tiger");
                    case "bear" -> getName(bearNames, habitats.get("Bear Habitat").size(), "Bear");
                    default -> "Unnamed";
                };

                // --- Create Animal record (generic container for output) ---
                Animal animal = new Animal(species, animalName, animalID, sex, color, weight,
                        birthDate, location, state, arrivalDate);

                // --- Add to proper habitat ---
                switch (species) {
                    case "hyena" -> habitats.get("Hyena Habitat").add(animal);
                    case "lion" -> habitats.get("Lion Habitat").add(animal);
                    case "tiger" -> habitats.get("Tiger Habitat").add(animal);
                    case "bear" -> habitats.get("Bear Habitat").add(animal);
                    default -> System.out.println("Unknown species: " + species);
                }
            }

        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }

        // --- Write organized report to zooPopulation.txt ---
        try (PrintWriter writer = new PrintWriter(new FileWriter(zooPopulationPath))) {
            writer.println("=== Zoo Population Report ===");
            writer.println("Generated: " + LocalDate.now());
            writer.println();

            for (Map.Entry<String, ArrayList<Animal>> entry : habitats.entrySet()) {
                writer.println(entry.getKey() + ":");
                for (Animal a : entry.getValue()) {
                    writer.printf("%s; %s; birth date: %s; %s; %s; %s pounds; from %s, %s; arrived %s%n",
                            a.getAnimalID(),
                            a.getAnimalName(),
                            a.getAnimalBirthDate(),     // <- Use this (instead of a.getBirthDate())
                            a.getAnimalColor(),         // <- Use this (instead of a.getColor())
                            a.getSex(),
                            a.getWeight(),
                            a.getAnimalLocation(),      // <- Use this (instead of a.getLocation())
                            a.getAnimalState(),         // <- Use this (instead of a.getState())
                            a.getAnimalArrivalDate()    // <- Use this (instead of a.getArrivalDate())
                    );
                }
                writer.println();
            }
        } catch (IOException e) {
            System.out.println("Error writing report: " + e.getMessage());
        }

        System.out.println("✅ Zoo population report generated successfully: zooPopulation.txt");
    }

    // ---------------- HELPER METHODS ---------------- //

    /**
     * Generates a random ISO 8601 birthdate based on the animal's age and season.
     * Handles unknown or missing seasons gracefully.
     */
    private static String genBirthDay(int age, String season) {
        Random rand = new Random();
        int currentYear = LocalDate.now().getYear();
        int birthYear = currentYear - age;
        int month, day;

        switch (season.toLowerCase()) {
            case "spring" -> month = 3 + rand.nextInt(3); // Mar–May
            case "summer" -> month = 6 + rand.nextInt(3); // Jun–Aug
            case "fall", "autumn" -> month = 9 + rand.nextInt(3); // Sep–Nov
            case "winter" -> {
                // Winter spans Dec–Feb (may go into previous year)
                if (rand.nextBoolean()) {
                    month = 12;
                    birthYear -= 1;
                } else {
                    month = 1 + rand.nextInt(2);
                }
            }
            default -> month = 1 + rand.nextInt(12); // Unknown → random month
        }

        day = rand.nextInt(LocalDate.of(birthYear, month, 1).lengthOfMonth()) + 1;
        return LocalDate.of(birthYear, month, day).toString(); // ISO 8601 format
    }

    /**
     * Generates a unique sequential ID based on species.
     * Format: [Two-letter prefix][zero-padded number], e.g., "Hy01", "Li04".
     */
    private static String genUniqueID(String species) {
        species = species.toLowerCase();
        String prefix = switch (species) {
            case "hyena" -> "Hy";
            case "lion" -> "Li";
            case "tiger" -> "Ti";
            case "bear" -> "Be";
            default -> "An";
        };
        int number = idCounters.merge(prefix, 1, Integer::sum);
        return String.format("%s%02d", prefix, number);
    }

    // Counter map to track how many animals per species
    private static final Map<String, Integer> idCounters = new HashMap<>();

    /**
     * Retrieves a name from the list (cycling if list is shorter than number of animals).
     */
    private static String getName(ArrayList<String> list, int index, String fallback) {
        if (list == null || list.isEmpty()) return "Unnamed " + fallback;
        return list.get(index % list.size());
    }
}
