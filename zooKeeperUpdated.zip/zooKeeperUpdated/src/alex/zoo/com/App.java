// aD 10/30/2025
package alex.zoo.com;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class App {
    public static void main(String[] args) {
        String filePath = "animalNames.txt";
        AnimalNameListsWrapper animalLists = Utilities.createAnimalNameLists(filePath);

        ArrayList<String> listOfHyenaNames = animalLists.getHyenaNames();
        ArrayList<String> listOfLionNames = animalLists.getLionNames();
        ArrayList<String> listOfBearNames = animalLists.getBearNames();
        ArrayList<String> listOfTigerNames = animalLists.getTigerNames();

        HashMap<String, Hyena> HyenaMap = new HashMap<>();
        HashMap<String, Lion> LionMap = new HashMap<>();
        HashMap<String, Tiger> TigerMap = new HashMap<>();
        HashMap<String, Bear> BearMap = new HashMap<>();

        File InputFile = new File("arrivingAnimals.txt");

        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader(InputFile))) {
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts.length < 5) continue;

                String[] first = parts[0].split(" ");
                int age = Integer.parseInt(first[0]);
                String sex = first[3];
                String species = first[4];
                String color = parts[2];
                String weight = parts[3];
                String location = parts[4].replace("from ", ""); // clean location
                String state = "";

                // --- Calculate approximate birth date based on age ---
                int currentYear = java.time.LocalDate.now().getYear();
                int birthYear = currentYear - age;
                String birthDate = birthYear + "-03-21"; // default March 21

                // Create and assign names
                switch (species.toLowerCase()) {
                    case "hyena" -> {
                        Hyena hyena = new Hyena(
                                sex,
                                weight,
                                age,
                                "",
                                "Hy0" + Hyena.getNumOfHyena(),
                                birthDate,
                                color,
                                location,
                                state
                        );
                        hyena.setAnimalArrivalDate(Utilities.arrivalDate());

                        if (!listOfHyenaNames.isEmpty()) {
                            int hyenaIndex = HyenaMap.size() % listOfHyenaNames.size();
                            hyena.setAnimalName(listOfHyenaNames.get(hyenaIndex));
                        } else {
                            hyena.setAnimalName("Unnamed Hyena");
                        }

                        HyenaMap.put(hyena.getAnimalID(), hyena);
                    }

                    case "lion" -> {
                        Lion lion = new Lion(
                                sex,
                                weight,
                                age,
                                "",
                                "Li0" + Lion.getNumOfLion(),
                                birthDate,
                                color,
                                location,
                                state
                        );
                        lion.setAnimalArrivalDate(Utilities.arrivalDate());

                        if (!listOfLionNames.isEmpty()) {
                            int lionIndex = LionMap.size() % listOfLionNames.size();
                            lion.setAnimalName(listOfLionNames.get(lionIndex));
                        } else {
                            lion.setAnimalName("Unnamed Lion");
                        }

                        LionMap.put(lion.getAnimalID(), lion);
                    }

                    case "tiger" -> {
                        Tiger tiger = new Tiger(
                                sex,
                                weight,
                                age,
                                "",
                                "Ti0" + Tiger.getNumOfTiger(),
                                birthDate,
                                color,
                                location,
                                state
                        );
                        tiger.setAnimalArrivalDate(Utilities.arrivalDate());

                        if (!listOfTigerNames.isEmpty()) {
                            int tigerIndex = TigerMap.size() % listOfTigerNames.size();
                            tiger.setAnimalName(listOfTigerNames.get(tigerIndex));
                        } else {
                            tiger.setAnimalName("Unnamed Tiger");
                        }

                        TigerMap.put(tiger.getAnimalID(), tiger);
                    }

                    case "bear" -> {
                        Bear bear = new Bear(
                                sex,
                                weight,
                                age,
                                "",
                                "Be0" + Bear.getNumOfBear(),
                                birthDate,
                                color,
                                location,
                                state
                        );
                        bear.setAnimalArrivalDate(Utilities.arrivalDate());

                        if (!listOfBearNames.isEmpty()) {
                            int bearIndex = BearMap.size() % listOfBearNames.size();
                            bear.setAnimalName(listOfBearNames.get(bearIndex));
                        } else {
                            bear.setAnimalName("Unnamed Bear");
                        }

                        BearMap.put(bear.getAnimalID(), bear);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file: " + e.getMessage());
        }

        // --- Print Report ---
        System.out.println("\n=== Zoo Animal Report ===\n");

        System.out.println("Hyenas:");
        HyenaMap.values().forEach(System.out::println);

        System.out.println("\nLions:");
        LionMap.values().forEach(System.out::println);

        System.out.println("\nTigers:");
        TigerMap.values().forEach(System.out::println);

        System.out.println("\nBears:");
        BearMap.values().forEach(System.out::println);

        System.out.println("\n=== End of Report ===");
    }
}
