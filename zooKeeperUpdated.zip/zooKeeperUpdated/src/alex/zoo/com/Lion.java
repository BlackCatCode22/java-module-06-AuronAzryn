package alex.zoo.com;

public class Lion extends Animal {
    private static int numOfLion = 0;

    public Lion(String sex, String weight, int age, String name, String animalID, String animalBirthDate, String animalColor, String animalLocation, String animalState) {
        super(sex, "lion", weight, age, name, animalID, animalBirthDate, animalColor, animalLocation, animalState);
        ++numOfLion;
    }

    @Override
    public String toString() {
        return "Lion Habitat: " + getAnimalID() + "; "
                + getAnimalName() + "; "
                + "birth date: " + (getAnimalBirthDate() != null ? getAnimalBirthDate() : "Unknown") + "; "
                + getAnimalColor() + "; "
                + getSex() + "; "
                + getWeight() + "; "
                + "from " + getAnimalLocation() + "; "
                + "arrived " + getAnimalArrivalDate();
    }

    public static int getNumOfLion() {
        return numOfLion;
    }
}
