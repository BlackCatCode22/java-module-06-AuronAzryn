package alex.zoo.com;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Random;

public class Utilities {

    public static AnimalNameListsWrapper createAnimalNameLists(String filePath) {
        ArrayList<String> hyenaNames = new ArrayList<>();
        ArrayList<String> lionNames = new ArrayList<>();
        ArrayList<String> tigerNames = new ArrayList<>();
        ArrayList<String> bearNames = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            String currentCategory = "";

            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                if (line.startsWith("Hyena Names")) currentCategory = "hyena";
                else if (line.startsWith("Lion Names")) currentCategory = "lion";
                else if (line.startsWith("Tiger Names")) currentCategory = "tiger";
                else if (line.startsWith("Bear Names")) currentCategory = "bear";
                else {
                    String[] names = line.split(",");
                    for (String name : names) {
                        String trimmed = name.trim();
                        if (trimmed.isEmpty()) continue;

                        switch (currentCategory) {
                            case "hyena" -> hyenaNames.add(trimmed);
                            case "lion" -> lionNames.add(trimmed);
                            case "tiger" -> tigerNames.add(trimmed);
                            case "bear" -> bearNames.add(trimmed);
                        }
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading animal names file: " + e.getMessage());
        }

        return new AnimalNameListsWrapper(hyenaNames, lionNames, tigerNames, bearNames);
    }

    public static String arrivalDate() {
        return LocalDate.now().toString();
    }

    // Generates a realistic birthdate based on age and season
    public static String generateBirthDate(int age, String season) {
        int currentYear = LocalDate.now().getYear();
        int birthYear = currentYear - age;

        int month = switch (season.toLowerCase()) {
            case "spring" -> randomBetween(3, 5);
            case "summer" -> randomBetween(6, 8);
            case "fall", "autumn" -> randomBetween(9, 11);
            case "winter" -> randomBetween(12, 12); // December
            default -> randomBetween(1, 12); // unknown season
        };

        int day = randomBetween(1, MonthDays(month));

        return String.format("%d-%02d-%02d", birthYear, month, day);
    }

    // Helper method for random number in range [min, max]
    private static int randomBetween(int min, int max) {
        return new Random().nextInt(max - min + 1) + min;
    }

    // Returns max days for each month (ignores leap year for simplicity)
    private static int MonthDays(int month) {
        return switch (month) {
            case 1, 3, 5, 7, 8, 10, 12 -> 31;
            case 4, 6, 9, 11 -> 30;
            case 2 -> 28;
            default -> 30;
        };
    }
}
