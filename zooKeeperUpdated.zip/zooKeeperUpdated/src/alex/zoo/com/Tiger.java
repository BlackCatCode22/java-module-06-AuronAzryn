package alex.zoo.com;

public class Tiger extends Animal {
    private static int numOfTiger = 0;

    public Tiger(String sex, String weight, int age, String name, String animalID, String animalBirthDate, String animalColor, String animalLocation, String animalState) {
        super(sex, "tiger", weight, age, name, animalID, animalBirthDate, animalColor, animalLocation, animalState);
        ++numOfTiger;
    }

    @Override
    public String toString() {
        return "Tiger Habitat: " + getAnimalID() + "; "
                + getAnimalName() + "; "
                + "birth date: " + (getAnimalBirthDate() != null ? getAnimalBirthDate() : "Unknown") + "; "
                + getAnimalColor() + "; "
                + getSex() + "; "
                + getWeight() + "; "
                + "from " + getAnimalLocation() + "; "
                + "arrived " + getAnimalArrivalDate();
    }

    public static int getNumOfTiger() {
        return numOfTiger;
    }
}
