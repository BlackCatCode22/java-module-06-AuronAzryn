package alex.zoo.com;

public class Animal {
    public static int NumOfAnimals;
    private String sex;
    private String species;
    private String weight;
    private int age;
    private String animalName;
    private String animalID;
    private String animalBirthDate;
    private String animalColor;
    private String animalLocation;
    private String animalState;
    private String animalArrivalDate;

    public Animal(String sex, String species, String weight, int age, String name, String animalID, String animalBirthDate, String animalColor, String animalLocation, String animalState) {
        ++NumOfAnimals;
        this.species = species;
        this.sex = sex;
        this.weight = weight;
        this.age = age;
        this.animalName = name;
        this.animalID = animalID;
        this.animalBirthDate = animalBirthDate;
        this.animalColor = animalColor;
        this.animalLocation = animalLocation;
        this.animalState = animalState;
    }

    public Animal(String sex, String species, int age, String name, String extraInfo, String color, String location, String state) {
        // Optional constructor for subclasses
        ++NumOfAnimals;
        this.sex = sex;
        this.species = species;
        this.age = age;
        this.animalName = name;
        this.animalColor = color;
        this.animalLocation = location;
        this.animalState = state;
    }

    // --- Getters and Setters ---
    public String getSex() { return sex; }
    public void setSex(String sex) { this.sex = sex; }

    public String getWeight() { return weight; }
    public void setWeight(String weight) { this.weight = weight; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getAnimalName() { return animalName; }
    public void setAnimalName(String animalName) { this.animalName = animalName; }

    public String getAnimalID() { return animalID; }
    public void setAnimalID(String animalID) { this.animalID = animalID; }

    public String getAnimalBirthDate() { return animalBirthDate; }
    public void setAnimalBirthDate(String animalBirthDate) { this.animalBirthDate = animalBirthDate; }

    public String getAnimalColor() { return animalColor; }
    public void setAnimalColor(String animalColor) { this.animalColor = animalColor; }

    public String getAnimalLocation() { return animalLocation; }
    public void setAnimalLocation(String animalLocation) { this.animalLocation = animalLocation; }

    public String getAnimalState() { return animalState; }
    public void setAnimalState(String animalState) { this.animalState = animalState; }

    public String getAnimalArrivalDate() { return animalArrivalDate; }
    public void setAnimalArrivalDate(String animalArrivalDate) { this.animalArrivalDate = animalArrivalDate; }

    public String getSpecies() { return species; }
    public void setSpecies(String species) { this.species = species; }

    public static int getNumOfAnimals() { return NumOfAnimals; }

    @Override
    public String toString() {
        return animalID + "; " + animalName + "; birth date: " + animalBirthDate + "; " +
                animalColor + "; " + sex + "; " + weight + "; from " + animalLocation + "; arrived " + animalArrivalDate;
    }
}
